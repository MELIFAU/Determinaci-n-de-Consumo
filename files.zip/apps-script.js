// =============================================
// COBRANZAS COFICO — Google Apps Script
// Pegá este código en tu Apps Script y desplegá
// =============================================

const SHEET_ID = SpreadsheetApp.getActiveSpreadsheet().getId();
const DATA_SHEET_NAME = "datos";

function getOrCreateSheet() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(DATA_SHEET_NAME);
  if (!sheet) {
    sheet = ss.insertSheet(DATA_SHEET_NAME);
    sheet.getRange("A1").setValue("json_data");
    sheet.getRange("B1").setValue("updated_at");
    sheet.getRange("C1").setValue("updated_by");
  }
  return sheet;
}

function doGet(e) {
  try {
    const sheet = getOrCreateSheet();
    const cell = sheet.getRange("A2").getValue();
    const updatedAt = sheet.getRange("B2").getValue();
    const updatedBy = sheet.getRange("C2").getValue();
    
    if (!cell) {
      return ContentService
        .createTextOutput(JSON.stringify({ ok: true, data: null, updated_at: null, updated_by: null }))
        .setMimeType(ContentService.MimeType.JSON);
    }
    
    return ContentService
      .createTextOutput(JSON.stringify({ 
        ok: true, 
        data: JSON.parse(cell), 
        updated_at: updatedAt ? updatedAt.toString() : null,
        updated_by: updatedBy || null
      }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch(err) {
    return ContentService
      .createTextOutput(JSON.stringify({ ok: false, error: err.message }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function doPost(e) {
  try {
    const payload = JSON.parse(e.postData.contents);
    const sheet = getOrCreateSheet();
    
    sheet.getRange("A2").setValue(JSON.stringify(payload.data));
    sheet.getRange("B2").setValue(new Date().toISOString());
    sheet.getRange("C2").setValue(payload.updated_by || "");
    
    return ContentService
      .createTextOutput(JSON.stringify({ ok: true, updated_at: new Date().toISOString() }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch(err) {
    return ContentService
      .createTextOutput(JSON.stringify({ ok: false, error: err.message }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}
